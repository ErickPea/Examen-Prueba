package com.example.pruedatienda.DTO;

public interface clientesDTO extends IGenericDTO{

	String getTipo_identificacion();
	
	String getIdentificacion();
	
	String getNombre_cliente();
	
	String getApellido_cliente();
	
	String getTelefono();
	
	String getDireccion();
	
	String getCiudad();
	
}
