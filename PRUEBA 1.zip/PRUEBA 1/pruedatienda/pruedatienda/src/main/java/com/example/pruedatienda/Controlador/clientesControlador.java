package com.example.pruedatienda.Controlador;

import com.example.pruedatienda.Entity.ABaseEntity;

public class clientesControlador     {

}
