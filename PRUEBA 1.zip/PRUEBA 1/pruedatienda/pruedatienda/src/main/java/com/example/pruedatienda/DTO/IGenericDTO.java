package com.example.pruedatienda.DTO;

public interface IGenericDTO {

	Long getId();
	String getEstado();
}
