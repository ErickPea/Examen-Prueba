package com.example.pruedatienda.IRepository;
import com.example.pruedatienda.Entity.productos;

import java.util.List;

import com.example.pruedatienda.DTO.productosDTO;
public interface productosREPOSITORY extends IBaseRepository<productos, Long> {

	
	
	
	
	
	
	List< productosDTO> getlistproductosDTO();
	
}
