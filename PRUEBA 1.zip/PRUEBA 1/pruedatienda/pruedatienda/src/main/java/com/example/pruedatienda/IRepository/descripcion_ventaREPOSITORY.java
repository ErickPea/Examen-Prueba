package com.example.pruedatienda.IRepository;
import com.example.pruedatienda.Entity.descripcion_ventas;

import java.util.List;

import com.example.pruedatienda.DTO.descripcion_ventanasDTO;
public interface descripcion_ventaREPOSITORY extends IBaseRepository<descripcion_ventas, Long> {
	
	
	
	
	
	
	
	
	List<descripcion_ventas> getdescripcion_ventas();

}
