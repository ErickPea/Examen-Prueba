package com.example.pruedatienda.IRepository;
import com.example.pruedatienda.Entity.ventas;

import java.util.List;

import com.example.pruedatienda.DTO.ventaDTO;
public interface ventasREPOSITORY extends IBaseRepository<ventas,Long> {

	
	
	
	
	
	
	
	
	List<ventaDTO> getListventaDTO();
}
