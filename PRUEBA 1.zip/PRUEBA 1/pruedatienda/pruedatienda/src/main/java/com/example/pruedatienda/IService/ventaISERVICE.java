package com.example.pruedatienda.IService;
import java.util.List;

import com.example.pruedatienda.DTO.ventaDTO;
import com.example.pruedatienda.Entity.ventas;
public interface ventaISERVICE extends IBaseService<ventas>{
List<ventaDTO> getListventaDTO();
	
}
