package com.example.pruedatienda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruedatiendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
