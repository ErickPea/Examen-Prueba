package com.example.pruedatienda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruedatiendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruedatiendaApplication.class, args);
	}

}
